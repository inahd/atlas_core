#!/bin/bash
# install_cycle.sh
#
# Run this once to install the Atlas remediation cycle infrastructure.
# Run from the directory containing the downloaded files.
#
# Usage: bash install_cycle.sh

set -e

ATLAS_ROOT="$HOME/atlas_core"

echo "Installing Atlas remediation cycle infrastructure to $ATLAS_ROOT..."

# Create directories
mkdir -p "$ATLAS_ROOT/docs/prompts/queue"
mkdir -p "$ATLAS_ROOT/docs/prompts/done"
mkdir -p "$ATLAS_ROOT/docs/prompts/skipped"
mkdir -p "$ATLAS_ROOT/docs/prompts/backlog"
mkdir -p "$ATLAS_ROOT/config"

# Copy docs
cp ATLAS_STATE_OF_THE_UNION.md "$ATLAS_ROOT/docs/"
cp ATLAS_CYCLE.md "$ATLAS_ROOT/docs/"
cp ATLAS_CYCLE_LOG.md "$ATLAS_ROOT/docs/"

# Copy skill files (to local reference — the live skills are on claude.ai)
cp atlas-state-SKILL.md "$ATLAS_ROOT/docs/skills-atlas-state.md"
cp npu-integrator-SKILL.md "$ATLAS_ROOT/docs/skills-npu-integrator.md"

# Copy task prompts
cp prompts/queue/*.md "$ATLAS_ROOT/docs/prompts/queue/"

# Copy runner script
cp scripts/run_cycle.sh "$ATLAS_ROOT/scripts/"
chmod +x "$ATLAS_ROOT/scripts/run_cycle.sh"

echo ""
echo "✓ Installed. Directory structure:"
echo ""
tree "$ATLAS_ROOT/docs/" -L 3 2>/dev/null || find "$ATLAS_ROOT/docs" -maxdepth 3 -type f | sort

echo ""
echo "Next steps:"
echo ""
echo "  1. Start the kernel:"
echo "     cd $ATLAS_ROOT && python kernel.py"
echo ""
echo "  2. Run the first task interactively:"
echo "     bash $ATLAS_ROOT/scripts/run_cycle.sh --task DS-001"
echo ""
echo "  3. Or run the full cycle with review between tasks:"
echo "     bash $ATLAS_ROOT/scripts/run_cycle.sh"
echo ""
echo "  4. Or run automatically (no pauses, stops at HUMAN_REQUIRED):"
echo "     bash $ATLAS_ROOT/scripts/run_cycle.sh --auto"
echo ""
echo "  Monitor progress:"
echo "     tail -f $ATLAS_ROOT/docs/ATLAS_CYCLE_LOG.md"
